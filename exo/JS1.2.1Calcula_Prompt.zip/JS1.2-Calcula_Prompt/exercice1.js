/**
 * Créer ici le projet « Calculaprompt ».
 */
