/**
 * Bonus 2 de Calculaprompt : document.write
 */
