/**
 * Bonus 1 de Calculaprompt : gestion des erreurs
 */
