/**
 * Calculawrite
 */
